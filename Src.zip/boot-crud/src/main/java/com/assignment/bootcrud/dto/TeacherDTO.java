package com.assignment.bootcrud.dto;

import lombok.Data;

@Data
public class TeacherDTO {
    private String name;
}
