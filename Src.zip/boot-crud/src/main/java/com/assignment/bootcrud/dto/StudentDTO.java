package com.assignment.bootcrud.dto;

import lombok.Data; // Lombok annotation for generating getters, setters, toString, hashCode, and equals methods

@Data // Lombok annotation to generate getters, setters, toString, hashCode, and equals methods
public class StudentDTO {

    private String name; // Name of the student
}
